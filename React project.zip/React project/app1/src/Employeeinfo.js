import { useState } from "react"
import "./App.css"
const Employeeinfo=()=>
{
 
 
 let [Salary,setSalary]=useState()
  let [Department,setDepartment]=useState()
 
 
 
 
  const handleName=(e)=>
  {
   setSalary(e.target.value)
  }
 
 
 
  const handleAge=(e)=>
  {
   setDepartment(e.target.value)
  }
     
    return (<div className="cont">
 
 
  <input type="text" placeholder="Enter ur salary" onChange={handleName}/>
 
     <input type="text" placeholder="Enter ur department" onChange={handleAge}/>
 
      <h1>Salary{Salary}</h1>
      <h2>Department{Department}</h2>
   
    </div>)
}
export default Employeeinfo
 
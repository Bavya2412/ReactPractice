import { useState } from "react"
import "./App.css"
const Userinfo=()=>
{
 
 
 let [Name,setName]=useState()
  let [age,setAge]=useState()
 
 
 
 
  const handleName=(e)=>
  {
   setName(e.target.value)
  }
 
 
 
  const handleAge=(e)=>
  {
   setAge(e.target.value)
  }
     
    return (<div className="cont">
 
 
  <input type="text" placeholder="Enter ur name" onChange={handleName}/>
 
     <input type="text" placeholder="Enter ur Age" onChange={handleAge}/>
 
      <h1>Name{Name}</h1>
      <h2> Age{age}</h2>
   
    </div>)
}
export default Userinfo
 
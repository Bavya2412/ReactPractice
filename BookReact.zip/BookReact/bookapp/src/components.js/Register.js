import React, { useState } from "react";
import { Form, Button, Segment, Header, Message } from "semantic-ui-react";
import API from "../services/api";
import { useNavigate, Link } from "react-router-dom";

const Register = () => {
  const [form, setForm] = useState({ username: "", password: "", roles: "USER" });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e, { name, value }) => {
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await API.post("/users/register", form);
      alert("Registered successfully!");
      navigate("/login");
    } catch {
      alert("Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Segment padded="very" stacked style={{ maxWidth: 400, margin: "60px auto" }}>
      <Header as="h2" textAlign="center" color="violet">
        Register
      </Header>
      <Form onSubmit={handleSubmit} loading={loading}>
        <Form.Input
          label="Username"
          name="username"
          value={form.username}
          onChange={handleChange}
          placeholder="Enter username"
          required
        />
        <Form.Input
          label="Password"
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          placeholder="Enter password"
          required
        />
        <Button fluid color="violet" type="submit">
          Register
        </Button>
      </Form>
      <Message info style={{ marginTop: "15px" }}>
        Already have an account? <Link to="/login">Login here</Link>
      </Message>
    </Segment>
  );
};

export default Register;

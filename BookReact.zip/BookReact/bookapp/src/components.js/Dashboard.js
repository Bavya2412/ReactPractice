import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Container, Header, Segment } from "semantic-ui-react";

const Dashboard = () => {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <Container textAlign="center" style={{ marginTop: "80px" }}>
      <Segment padded>
        <Header as="h2" color="blue" style={{ marginBottom: "30px" }}>
          📘 Book Manager Dashboard
        </Header>

        <Button color="green" onClick={() => navigate("/add")} style={{ margin: "10px" }}>
          ➕ Add Book
        </Button>

        <Button color="blue" onClick={() => navigate("/books")} style={{ margin: "10px" }}>
          📚 View Books
        </Button>

        <Button color="red" onClick={logout} style={{ margin: "10px" }}>
          🚪 Logout
        </Button>
      </Segment>
    </Container>
  );
};

export default Dashboard;

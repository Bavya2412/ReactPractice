import React, { useState, useEffect } from "react";
import { Form, Button, Container, Header } from "semantic-ui-react";
import API from "../services/api";
import { useNavigate, useParams } from "react-router-dom";

const BookForm = () => {
  const [book, setBook] = useState({ isbn: "", title: "", author: "", publicationYear: "" });
  const { isbn } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (isbn) {
      API.get(`/books/${isbn}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }).then(res => setBook(res.data));
    }
  }, [isbn]);

  const handleChange = (e, { name, value }) => {
    setBook(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    const token = localStorage.getItem("token");
    try {
      if (isbn) {
        await API.put(`/books/${isbn}`, book, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await API.post("/books", book, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      navigate("/books");
    } catch (error) {
      alert("Book save failed.");
    }
  };

  return (
    <Container text style={{ marginTop: "50px" }}>
      <Header as="h2" color="blue" textAlign="center">
        {isbn ? "Edit Book" : "Add Book"}
      </Header>
      <Form onSubmit={handleSubmit}>
        {!isbn && (
          <Form.Input
            label="ISBN"
            name="isbn"
            value={book.isbn}
            onChange={handleChange}
            required
            placeholder="Enter ISBN"
          />
        )}
        <Form.Input
          label="Title"
          name="title"
          value={book.title}
          onChange={handleChange}
          required
          placeholder="Enter book title"
        />
        <Form.Input
          label="Author"
          name="author"
          value={book.author}
          onChange={handleChange}
          required
          placeholder="Enter author name"
        />
        <Form.Input
          label="Publication Year"
          name="publicationYear"
          type="number"
          value={book.publicationYear}
          onChange={handleChange}
          required
          placeholder="Enter year"
        />
        <Button fluid color="blue" type="submit">
          Save Book
        </Button>
      </Form>
    </Container>
  );
};

export default BookForm;

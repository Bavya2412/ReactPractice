import React from "react";
import { Menu, Container, Button } from "semantic-ui-react";
import { Link, useNavigate } from "react-router-dom";

const NavBar = () => {
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <Menu
      inverted
      style={{
        background: "linear-gradient(to right, #4a148c, #6a1b9a)",
        borderRadius: 0,
        marginBottom: "30px",
      }}
    >
      <Container>
        <Menu.Item header as={Link} to="/dashboard">
          📚 Book Manager
        </Menu.Item>

        {token ? (
          <>
            <Menu.Item as={Link} to="/books" name="Books" />
            <Menu.Item position="right">
              <Button color="purple" onClick={handleLogout}>
                Logout
              </Button>
            </Menu.Item>
          </>
        ) : (
          <>
            <Menu.Item position="right">
              <Button basic inverted as={Link} to="/login">
                Login
              </Button>
            </Menu.Item>
            <Menu.Item>
              <Button color="violet" as={Link} to="/register">
                Register
              </Button>
            </Menu.Item>
          </>
        )}
      </Container>
    </Menu>
  );
};

export default NavBar;

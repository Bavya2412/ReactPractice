import React, { useEffect, useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import { Button, Card, Container, Grid, Header } from "semantic-ui-react";

const BookList = () => {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate();

  const loadBooks = async () => {
    try {
      const res = await API.get("/books", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setBooks(res.data);
    } catch {
      alert("Unauthorized or failed to fetch books.");
    }
  };

  const handleDelete = async (isbn) => {
    if (window.confirm("Delete this book?")) {
      await API.delete(`/books/${isbn}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      loadBooks();
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  return (
    <Container style={{ marginTop: "40px" }}>
      <Header as="h2" textAlign="center" color="blue">
        📚 Book Collection
      </Header>

      <Button
        color="green"
        floated="right"
        onClick={() => navigate("/add")}
        style={{ marginBottom: "20px" }}
      >
        Add Book
      </Button>

      <Grid columns={4} stackable>
        {books.map((book) => (
          <Grid.Column key={book.isbn}>
            <Card fluid>
              <Card.Content>
                <Card.Header>{book.title}</Card.Header>
                <Card.Meta>{book.author}</Card.Meta>
                <Card.Description>
                  Published in {book.publicationYear}
                </Card.Description>
              </Card.Content>
              <Card.Content extra>
                <div className="ui two buttons">
                  <Button color="blue" onClick={() => navigate(`/edit/${book.isbn}`)}>
                    Edit
                  </Button>
                  <Button color="red" onClick={() => handleDelete(book.isbn)}>
                    Delete
                  </Button>
                </div>
              </Card.Content>
            </Card>
          </Grid.Column>
        ))}
      </Grid>
    </Container>
  );
};

export default BookList;

const Night=()=>
{
    return(<>
      <h1> Good Night</h1>
   
    </>)
}
export default Night
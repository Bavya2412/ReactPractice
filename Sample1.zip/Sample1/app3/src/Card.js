import { useState } from "react";

const Card = ({ id, title, pic, price, category, RemoveData, UpdateCategory }) => {
  const [newCategory, setNewCategory] = useState("");

  return (
    <div className="card">
      <h3>{title}</h3>
      <p>Category: {category}</p>
      <p>Price: ₹{price}</p>
      <img src={pic} alt={title} />
      <br />

      <input
        type="text"
        placeholder="New Category"
        value={newCategory}
        onChange={(e) => setNewCategory(e.target.value)}
      />
      <button onClick={() => UpdateCategory(id, newCategory)}>Update Category</button>

      <button onClick={() => RemoveData(id)}>Remove</button>
    </div>
  );
};

export default Card;

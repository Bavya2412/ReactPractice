import { useEffect, useState } from "react"
import Card from "./Card"
import SCard from "./Scard"
 
const ApiEX=()=>
{
 
 
    // remove ...  id
   let [Products,setProducts]=useState([])
   let [FProducts,setFProducts]=useState([])
 
   let [search,setSearch]=useState("")
 
   const handleSearch=(e)=>
   {
 
    setSearch(e.target.value)
   }
    useEffect(()=>
        {
       
              fetch("https://dummyjson.com/products")
              .then((res)=>res.json())
              .then((temp)=>setProducts(temp.products))
              .catch((e)=>console.log(e))
 
 
        } ,[])
 
        useEffect(()=>
            {
                let data=Products.filter((temp)=>temp.category.includes(search))
                setFProducts(data)
            },[search,Products])
 
 
 
    const RemoveData=(id)=>
    {
        setProducts(Products.filter((temp)=>temp.id!=id))
    }
 
    const UpdateCategory = (id, newCategory) => {
        const updated = Products.map((item) =>
          item.id === id ? { ...item, category: newCategory } : item
        );
        setProducts(updated);
      };
      
 
    return(<>
 
  <input type="text" placeholder="search by..." onChange={handleSearch}/>
 
 {
 
   search.length ?
 
      FProducts.map((temp)=><SCard id={temp.id} title={temp.title} pic={temp.thumbnail} price={temp.price}category={temp.category} RemoveData={RemoveData} UpdateCategory={UpdateCategory}/> )
:
   Products.map((temp)=><SCard id={temp.id} title={temp.title} pic={temp.thumbnail} price={temp.price}category={temp.category} RemoveData={RemoveData} UpdateCategory={UpdateCategory}/> )
 
 }
   
   
    </>)
}
export default ApiEX
 
 
// useEffect (()=> , [])
// useEffect(()=> ,[a])
 
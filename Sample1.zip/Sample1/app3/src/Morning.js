const Morning=()=>
{
    return(<>
      <h1> Good Morning </h1>
   
    </>)
}
export default Morning
 
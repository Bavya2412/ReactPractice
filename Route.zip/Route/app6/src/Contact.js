const Contact = () => {
    return (
      <div>
        <h2>Contact Us</h2>
        <p>Phone: +91-9876543210</p>
        <p>Email: support@techworld.com</p>
      </div>
    );
  };
  
  export default Contact;
  
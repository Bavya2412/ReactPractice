const ShowPay = ({ payslipData }) => {
    if (!payslipData) return <h3>No payslip data available</h3>;
  
    const { name, id, basic, bonus, total } = payslipData;
  
    return (
      <div style={{ padding: "20px" }}>
        <h2>Payslip Details</h2>
        <p>Name: {name}</p>
        <p>ID: {id}</p>
        <p>Basic Salary:₹{basic}</p>
        <p>Bonus: ₹{bonus}</p>
        <p>Total Salary: ₹{total}</p>
      </div>
    );
  };
  
  export default ShowPay;
  
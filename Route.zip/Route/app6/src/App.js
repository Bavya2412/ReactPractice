// App.js
import { Link } from "react-router-dom";
import { useState } from "react";
import AppRoutes from "./Routes"; // This should be Routes.js
import UCard from "./UCard";

const App = () => {
  const [payslipData, setPayslipData] = useState(null);

  const [users, setUsers] = useState([
    { UserId: "101", Name: "asha", Salary: 200 },
    { UserId: "102", Name: "ajay", Salary: 400 },
    { UserId: "103", Name: "jatin", Salary: 800 },
    { UserId: "104", Name: "komal", Salary: 700 },
  ]);

  const [electronicItems] = useState([
    { itemCode: 101, name: "Laptop", price: 55000, quantity: 10, city: "Delhi" },
    { itemCode: 102, name: "Smartphone", price: 25000, quantity: 30, city: "Mumbai" },
    { itemCode: 103, name: "Tablet", price: 18000, quantity: 15, city: "Bangalore" },
    { itemCode: 104, name: "Smartwatch", price: 5000, quantity: 25, city: "Hyderabad" },
    { itemCode: 105, name: "Bluetooth Speaker", price: 3000, quantity: 20, city: "Chennai" },
    { itemCode: 106, name: "Wireless Mouse", price: 700, quantity: 40, city: "Pune" },
    { itemCode: 107, name: "Keyboard", price: 1200, quantity: 35, city: "Kolkata" },
    { itemCode: 108, name: "Monitor", price: 9000, quantity: 12, city: "Ahmedabad" },
    { itemCode: 109, name: "Printer", price: 6000, quantity: 8, city: "Jaipur" },
    { itemCode: 110, name: "Router", price: 2500, quantity: 18, city: "Lucknow" },
  ]);

  return (
    <div>
      {/* Display user cards */}
      {users.map((temp) => (
        <UCard
          key={temp.UserId}
          UserId={temp.UserId}
          Name={temp.Name}
          Salary={temp.Salary}
        />
      ))}

      {/* Navigation Bar */}
      <nav className="navbar">
        <Link to="/">Home</Link>
        <Link to="/signin">Sign In</Link>
        <Link to="/about">About</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/payslip">Payslip</Link>
        <Link to="/items">Electronic Items</Link> {/* ✅ Added route */}
      </nav>

      {/* Routes from separate file */}
      <AppRoutes
        payslipData={payslipData}
        setPayslipData={setPayslipData}
        users={users}
        setUsers={setUsers}
        electronicItems={electronicItems}
      />
    </div>
  );
};

export default App;

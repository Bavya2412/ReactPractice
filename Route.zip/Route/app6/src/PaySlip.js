import { useState } from "react";
import { useNavigate } from "react-router-dom";

const PaySlip = ({ setPayslipData }) => {
  const [name, setName] = useState("");
  const [id, setId] = useState("");
  const [basic, setBasic] = useState("");
  const navigate = useNavigate();

  const handleSubmit = () => {
    const b = parseFloat(basic);
    const bonus = b <= 5000 ? b * 0.05 : b * 0.1;
    const total = b + bonus;

    setPayslipData({ name, id, basic: b, bonus, total });
    navigate("/showpay");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Payslip Calculator</h2>
      <input placeholder="Name" onChange={(e) => setName(e.target.value)} /><br />
      <input placeholder="ID" onChange={(e) => setId(e.target.value)} /><br />
      <input placeholder="Basic Salary" onChange={(e) => setBasic(e.target.value)} /><br />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default PaySlip;

// ItemList.js
const Item = ({ items }) => {
    return (
      <div style={{ padding: "20px" }}>
        <h2>Electronic Items</h2>
        {items.map((item) => (
          <div key={item.itemCode} style={{ border: "1px solid #ccc", marginBottom: "10px", padding: "10px" }}>
            <h3>{item.name}</h3>
            <p>Price: ₹{item.price}</p>
            <p>Quantity: {item.quantity}</p>
            <p>City: {item.city}</p>
          </div>
        ))}
      </div>
    );
  };
  
  export default Item;
  
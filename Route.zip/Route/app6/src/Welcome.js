import { useLocation } from "react-router-dom";

const Welcome = () => {
  const { state } = useLocation();
  const { Id, password } = state || {};

  return (
    <div className="welcome">
      <h1>Welcome, {Id}!</h1>
      <p>Your password is: {password}</p>
    </div>
  );
};

export default Welcome;

const About = () => {
    return (
      <div>
        <h2>About Our Company</h2>
        <p>Company Name: TechWorld Pvt Ltd</p>
        <p>Founded: 2015</p>
        <p>Focus: Providing high-quality software development services and tech solutions.</p>
      </div>
    );
  };
  
  export default About;
  
import { Routes, Route } from "react-router-dom";
import Home from "./Home";
import SignIn from "./SignIn";
import About from "./About";
import Contact from "./Contact";
import PaySlip from "./PaySlip";
import ShowPay from "./ShowPay";
import Item from "./Item"; // ✅ Import this

const AppRoutes = ({ payslipData, setPayslipData, users, setUsers, electronicItems }) => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/signin" element={<SignIn />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/payslip" element={<PaySlip setPayslipData={setPayslipData} />} />
      <Route path="/showpay" element={<ShowPay payslipData={payslipData} />} />
      <Route path="/items" element={<Item items={electronicItems} />} /> {/* ✅ New route */}
    </Routes>
  );
};

export default AppRoutes;

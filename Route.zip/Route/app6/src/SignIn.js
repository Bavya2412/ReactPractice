import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./App.css";

const SignIn = () => {
  const [Id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [newPass, setNewPass] = useState("");
  const nav = useNavigate();

  const handleUserId = (e) => setId(e.target.value);
  const handleUserPassword = (e) => setPassword(e.target.value);
  const handleNewPassword = (e) => setNewPass(e.target.value);

  const Signup = () => {
    localStorage.setItem(Id, password);
    alert("Sign up successful");
  };

  const SignIn = () => {
    let p = localStorage.getItem(Id);
    if (p === password) {
      nav("/welcome", { state: { Id, password } });
    } else {
      alert("Incorrect Password. Try again");
    }
  };

  const UpdatePassword = () => {
    if (localStorage.getItem(Id)) {
      localStorage.setItem(Id, newPass);
      alert("Password updated successfully");
      setNewPass("");
    } else {
      alert("User ID not found");
    }
  };

  return (
    <div className="form-container">
      <h2>Sign In Page</h2>
      <input placeholder="Enter your User Id" onChange={handleUserId} /><br />
      <input type="password" placeholder="Enter your Password" onChange={handleUserPassword} /><br />
      <button onClick={SignIn}>Sign In</button>
      <button onClick={Signup}>Sign Up</button><br />

      <input type="password" placeholder="New Password" onChange={handleNewPassword} /><br />
      <button onClick={UpdatePassword}>Update Password</button>
    </div>
  );
};

export default SignIn;
